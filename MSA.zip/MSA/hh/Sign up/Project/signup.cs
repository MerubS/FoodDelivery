﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class signup : UserControl
    {
        public signup()
        {
            InitializeComponent();
           

        }

        private void username_TextChanged(object sender, EventArgs e)
        {

        }

        private void username_Enter(object sender, EventArgs e)
        {
            if (username.Text == "Username")
            {
                username.Text = "";
                username.ForeColor = Color.Black;
            }
        }

        private void username_Leave(object sender, EventArgs e)
        {
            if (username.Text == "")
            {
                username.Text = "Username";
                username.ForeColor = Color.Silver;
            }
        }

        private void email_Enter(object sender, EventArgs e)
        {
            if (email.Text == "someone@example.com")
            {
                email.Text = "";
                email.ForeColor = Color.Black;
            }
        }

        private void email_Leave(object sender, EventArgs e)
        {
            if (email.Text == "")
            {
                email.Text = "someone@example.com";
                email.ForeColor = Color.Silver;
            }
        }

        private void pass_TextChanged(object sender, EventArgs e)
        {

        }

        private void pass_Enter(object sender, EventArgs e)
        {
            if (pass.Text == "Password")
            {
                pass.Text = "";
                pass.ForeColor = Color.Black;
            }
        }

        private void pass_Leave(object sender, EventArgs e)
        {
            if (pass.Text == "")
            {
                pass.Text = "Password";
                pass.ForeColor = Color.Silver;
            }
        }

        private void cpass_Enter(object sender, EventArgs e)
        {
            if (cpass.Text == "Confirm Password")
            {
                cpass.Text = "";
                cpass.ForeColor = Color.Black;
            }
        }

        private void cpass_Leave(object sender, EventArgs e)
        {
            if (cpass.Text == "")
            {
                cpass.Text = "Confirm Password";
                cpass.ForeColor = Color.Silver;
            }
        }

        private void address_Enter(object sender, EventArgs e)
        {
            if (address.Text == "Address")
            {
                address.Text = "";
                address.ForeColor = Color.Black;
            }
        }

        private void address_Leave(object sender, EventArgs e)
        {
            if (address.Text == "")
            {
                address.Text = "Address";
                address.ForeColor = Color.Silver;
            }
        }

        private void contact_Enter(object sender, EventArgs e)
        {
            if (contact.Text == "Contact")
            {
                contact.Text = "";
                contact.ForeColor = Color.Black;
            }
        }

        private void contact_Leave(object sender, EventArgs e)
        {
            if (contact.Text == "")
            {
                contact.Text = "Contact";
                contact.ForeColor = Color.Black;
            }
        }
    }
}
