﻿select userinfo.USERNAME, userinfo.ID , userinfo.PASSWORD, useraccount.Address, useraccount.Contact,
useraccount.Email, useraccount.ID
From userinfo INNER JOIN useraccount ON userinfo.ID=useraccount.ID