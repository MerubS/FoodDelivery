﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;





namespace Foodie_menu
{
    
    public partial class exclusive1 : UserControl
    {

        myCart obj = new myCart();
        public exclusive1()
        {
            InitializeComponent();           
        }


        private void exclusive_Load(object sender, EventArgs e)
        {

        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }



        public void work()          /// To MARK/UnMARK previously saved customer favorites
        {

            pizzaFav_button.BackColor = Color.White;
            pastaFav_button.BackColor = Color.White;
            sandwhichFav_button.BackColor = Color.White;
            burgerFav_button.BackColor = Color.White;
            friesFav_button.BackColor = Color.White;

            foreach (string fav in myCart.favorites)
            {
                if (fav == "Pizza") { pizzaFav_button.BackColor = Color.OrangeRed; }
                if (fav == "Pasta") { pastaFav_button.BackColor = Color.OrangeRed; }
                if (fav == "Sandwhich") { sandwhichFav_button.BackColor = Color.OrangeRed; }
                if (fav == "Burger") { burgerFav_button.BackColor = Color.OrangeRed; }
                if (fav == "French Fries") { friesFav_button.BackColor = Color.OrangeRed; }
            }

            if (obj.GET_Reviews(0) <= 5) { pizza_Rating.Value = obj.GET_Reviews(0); }
            else { pizza_Rating.Value = 5; }
            if (obj.GET_Reviews(1) <= 5) { pasta_Rating.Value = obj.GET_Reviews(1); }
            else {pasta_Rating.Value = 5; } 
            if (obj.GET_Reviews(2) <= 5) { sandwhich_Rating.Value = obj.GET_Reviews(2); }
            else { sandwhich_Rating.Value = 5; }
            if(obj.GET_Reviews(3) <= 5) { burger_Rating.Value = obj.GET_Reviews(3); }
            else { burger_Rating.Value = 5; }
            if(obj.GET_Reviews(4) <= 5) { fries_Rating.Value = obj.GET_Reviews(4); }
            else { fries_Rating.Value = 5; }
          

        }



        /////////////////////         ADD TO Cart Buttons        ////////////////////

        private void pizza_button_Click(object sender, EventArgs e)
        {
           
             obj.addItem("Pizza");
            if (myCart.index1 < 20)
                flag_1.Visible = true;
            timer1.Start();
            
        }

        private void pasta_button_Click(object sender, EventArgs e)
        {

            obj.addItem("Pasta");
            if (myCart.index1 < 20)
                flag_2.Visible = true;
            timer1.Start();
        }

        private void sandwhich_button_Click(object sender, EventArgs e)
        {
            obj.addItem("Sandwhich");
            if (myCart.index1 < 20)
                flag_3.Visible = true;
            timer1.Start();
        }
        private void burger_button_Click(object sender, EventArgs e)
        {
            obj.addItem("Burger");
            if (myCart.index1 < 20)
                flag_4.Visible = true;
            timer1.Start();
        }
        private void fries_button_Click(object sender, EventArgs e)
        {
            obj.addItem("French Fries");
            if (myCart.index1 < 20)
                flag_5.Visible = true;
            timer1.Start();
        }


        ///////////////////      ADD TO FAVORITES SECTION       ///////////////////

        private void pizzaFav_button_Click(object sender, EventArgs e)
        {
        
            if (pizzaFav_button.BackColor == Color.White)
            {
                pizzaFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Pizza");
                L_1.Visible = true;
                timer1.Start();

            }
            else
            {
                pizzaFav_button.BackColor = Color.White;
                obj.removeFavorite("Pizza");

            }
        }

        private void pastaFv_button_Click(object sender, EventArgs e)
        {
      
            if (pastaFav_button.BackColor == Color.White)
            {
                pastaFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Pasta");
                L_2.Visible = true;
                timer1.Start();
            }
            else
            {
                pastaFav_button.BackColor = Color.White;
                obj.removeFavorite("Pasta");
            }
        }

        private void sandwhichFav_button_Click(object sender, EventArgs e)
        {
      
            if (sandwhichFav_button.BackColor == Color.White)
            {
                sandwhichFav_button.BackColor = Color.OrangeRed;          
                obj.addFavorite("Sandwhich");
                L_3.Visible = true;
                timer1.Start();
            }
            else
            {
                sandwhichFav_button.BackColor = Color.White;
                obj.removeFavorite("Sandwhich");
            }
        }

        private void burgerFav_buton_Click(object sender, EventArgs e)
        {
          
            if (burgerFav_button.BackColor == Color.White)
            {
                burgerFav_button.BackColor = Color.OrangeRed;            
                obj.addFavorite("Burger");
                L_4.Visible = true;
                timer1.Start();
            }
            else
            {
                burgerFav_button.BackColor = Color.White;
                obj.removeFavorite("Burger");
            }
        }

        private void friesFav_button_Click(object sender, EventArgs e)
        {
           
            if (friesFav_button.BackColor == Color.White)
            {
                friesFav_button.BackColor = Color.OrangeRed;           
                obj.addFavorite("French Fries");
                L_5.Visible = true;
                timer1.Start();
            }
            else
            {
                friesFav_button.BackColor = Color.White;
                obj.removeFavorite("French Fries");
            }
        }



        /////////// Timer For Add to fav/ add to cart labels///////
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (flag_1.Visible || flag_2.Visible || flag_3.Visible || flag_4.Visible || flag_5.Visible)
            {
                flag_1.Visible = false;
                flag_2.Visible = false;
                flag_3.Visible = false;
                flag_4.Visible = false;
                flag_5.Visible = false;
                timer1.Stop();
            }

             if (L_1.Visible || L_2.Visible || L_3.Visible || L_4.Visible || L_5.Visible)
            {
                L_1.Visible = false;
                L_2.Visible = false;
                L_3.Visible = false;
                L_4.Visible = false;
                L_5.Visible = false;
                timer1.Stop();
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {







        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
