﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class review2 : UserControl
    {
        myCart2 obj = new myCart2();
        public review2()
        {
            InitializeComponent();
        }

        public void work()
        {
            latte_rating.Value = obj.GET_myReview(0);
            cappuccino_rating.Value = obj.GET_myReview(1);
            cortado_rating.Value = obj.GET_myReview(2);
            mocha_rating.Value = obj.GET_myReview(3);
            americano_rating.Value = obj.GET_myReview(4);
            lungo_rating.Value = obj.GET_myReview(5);
            blackcoffee_rating.Value = obj.GET_myReview(6);
            espresso_rating.Value = obj.GET_myReview(7);
            tea_rating.Value = obj.GET_myReview(8);
            mazagran_rating.Value = obj.GET_myReview(9);
        }
        private void submit_button_Click(object sender, EventArgs e)
        {
            obj.SET_myReview(0,latte_rating.Value);
            obj.SET_myReview(1,cappuccino_rating.Value);
            obj.SET_myReview(2,cortado_rating.Value);
            obj.SET_myReview(3,mocha_rating.Value);
            obj.SET_myReview(4,americano_rating.Value);
            obj.SET_myReview(5,lungo_rating.Value);
            obj.SET_myReview(6,blackcoffee_rating.Value);
            obj.SET_myReview(7,espresso_rating.Value);
            obj.SET_myReview(8,tea_rating.Value);
            obj.SET_myReview(9,mazagran_rating.Value);

            obj.file_updater();

            flag.Visible = true;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            flag.Visible = false;
            timer1.Stop();
        }
    }
}
