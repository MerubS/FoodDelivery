﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class cart1 : UserControl
    {


        myCart obj = new myCart();

        public cart1()
        {
            InitializeComponent();
        }   // Default Cnstructor

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bill_label_Click(object sender, EventArgs e)
        {

        }

        private void item_list_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cart1_Load(object sender, EventArgs e)
        {

        }



        public void work()               // This function is used to update the bill tab 
        {
            item_list.Items.Clear();
            for(int i=0; i<myCart.index1;i++)
            {
                item_list.Items.Add(myCart.items[i]);
            }
            bill_label.Text = "Rs." + obj._bill;
        }


        //////////////////           Cart  Buttons            /////////////// 
       
        

        private void checkout_button_Click(object sender, EventArgs e)
        {
            if( obj._bill == 0)
            {
                MessageBox.Show("You Can't Checkout With An Empty Cart", "Proceed To Checkout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else    ///// Check out
            {
                Delivery d = new Delivery();
                d.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if ((string)item_list.SelectedItem == "Pizza") { obj.removeItem("Pizza"); }
            else if ((string)item_list.SelectedItem == "Pasta") { obj.removeItem("Pasta"); }
            else if ((string)item_list.SelectedItem == "Burger") { obj.removeItem("Burger"); }
            else if ((string)item_list.SelectedItem == "French Fries") { obj.removeItem("French Fries"); }
            else if ((string)item_list.SelectedItem == "Sandwhich") { obj.removeItem("Sandwhich"); }
            else if ((string)item_list.SelectedItem == "Pulao") { obj.removeItem("Pulao"); }
            else if ((string)item_list.SelectedItem == "Daal Mix") { obj.removeItem("Daal Mix"); }
            else if ((string)item_list.SelectedItem == "Chicken Roast") { obj.removeItem("Chicken Roast"); }
            else if ((string)item_list.SelectedItem == "Mutton Karahi") { obj.removeItem("Mutton Karahi"); }
            else if ((string)item_list.SelectedItem == "Haleem") { obj.removeItem("Haleem"); }
            else { MessageBox.Show("Please Select An Item To Remove", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); }

            bill_label.Text = "Rs." + obj._bill;
            item_list.Items.Remove(item_list.SelectedItem);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void coupon_button_Click(object sender, EventArgs e)
        {
            myCart obj = new myCart();
            
            if (obj.getcoupon() == coupon_box.Text)
            {
                myCart.bill -= ((int)0.01 * myCart.bill);
            }

            bill_label.Text = myCart.bill.ToString();
        }
    }
}
