﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class exclusive2 : UserControl
    {
        myCart2 obj = new myCart2();
        public exclusive2()
        {
            InitializeComponent();
        }

        private void flag_2_Click(object sender, EventArgs e)
        {

        }


        public void work()
        {
            latteFav_button.BackColor = Color.White;
            capuccinoFav_button.BackColor = Color.White;
            cortadoFav_button.BackColor = Color.White;
            mochaFav_button.BackColor = Color.White;
            americanoFav_button.BackColor = Color.White;

            foreach (string fav in myCart2.favorites_2)
            {
                if (fav == "Latte") { latteFav_button.BackColor = Color.OrangeRed; }
                if (fav == "Cappuccino") { capuccinoFav_button.BackColor = Color.OrangeRed; }
                if (fav == "Cortado") { cortadoFav_button.BackColor = Color.OrangeRed; }
                if (fav == "Mocha") { mochaFav_button.BackColor = Color.OrangeRed; }
                if (fav == "Americano") { americanoFav_button.BackColor = Color.OrangeRed; }
            }

            if (obj.GET_Reviews(0) <= 5) { latte_rating.Value = obj.GET_Reviews(0); }
            else { latte_rating.Value = 5; }
            if (obj.GET_Reviews(1) <= 5) { capuccino_rating.Value = obj.GET_Reviews(1); }
            else { capuccino_rating.Value = 5; }
            if (obj.GET_Reviews(2) <= 5) { cortado_rating.Value = obj.GET_Reviews(2); }
            else { cortado_rating.Value = 5; }
            if (obj.GET_Reviews(3) <= 5) { mocha_rating.Value = obj.GET_Reviews(3); }
            else { mocha_rating.Value = 5; }
            if (obj.GET_Reviews(4) <= 5) { americano_rating.Value = obj.GET_Reviews(4); }
            else { americano_rating.Value = 5; }


        }             /// Updates changes to the user interface


        ////////////////////// Add to cart buttons ///////////////////
        private void latte_button_Click(object sender, EventArgs e)
        {
            obj.addItem("Latte");
            if (myCart2.index1_2 < 20)
                flag_1.Visible = true; flag_1.Text = "Added To Cart";
            timer1.Start();
        }


        private void capuccino_button_Click(object sender, EventArgs e)
        {
            obj.addItem("Cappuccino");
            if (myCart2.index1_2 < 20)
                flag_2.Visible = true; flag_2.Text = "Added To Cart";
            timer1.Start();
        }

        private void cortado_button_Click(object sender, EventArgs e)
        {
            obj.addItem("Cortado");
            if (myCart2.index1_2 < 20)
                flag_3.Visible = true; flag_3.Text = "Added To Cart";
            timer1.Start();
        }

        private void mocha_button_Click(object sender, EventArgs e)
        {
            obj.addItem("Mocha");
            if (myCart2.index1_2 < 20)
                flag_4.Visible = true; flag_4.Text = "Added To Cart";
            timer1.Start();
        }

        private void americano_button_Click(object sender, EventArgs e)
        {
            obj.addItem("Americano");
            if (myCart2.index1_2 < 20)
                flag_5.Visible = true; flag_5.Text = "Added To Cart";
            timer1.Start();
        }



        ////////////////// Add to favorites buttons //////////////


        private void latte_favorite_Click(object sender, EventArgs e)
        {
            if (latteFav_button.BackColor == Color.White)
            {
                latteFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Latte");
                flag_1.Visible = true; flag_1.Text = "Added To Favorites";
                timer1.Start();
            }
            else
            {
                latteFav_button.BackColor = Color.White;
                obj.removeFavorite("Latte");
            }
        }

        private void capuccinoFav_button_Click(object sender, EventArgs e)
        {
            if (capuccinoFav_button.BackColor == Color.White)
            {
                capuccinoFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Cappuccino");
                flag_2.Visible = true; flag_2.Text = "Added To Favorites";
                timer1.Start();
            }
            else
            {
                capuccinoFav_button.BackColor = Color.White;
                obj.removeFavorite("Cappuccino");
            }
        }

        private void cortadoFav_button_Click(object sender, EventArgs e)
        {
            if (cortadoFav_button.BackColor == Color.White)
            {
                cortadoFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Cortado");
                flag_3.Visible = true; flag_3.Text = "Added To Favorites";
                timer1.Start();
            }
            else
            {
                cortadoFav_button.BackColor = Color.White;
                obj.removeFavorite("Cortado");
                timer1.Start();
            }
        }

        private void mochaFav_button_Click(object sender, EventArgs e)
        {
            if (mochaFav_button.BackColor == Color.White)
            {
                mochaFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Mocha");
                flag_4.Visible = true; flag_4.Text = "Added To Favorites";
                timer1.Start();
            }
            else
            {
                mochaFav_button.BackColor = Color.White;
                obj.removeFavorite("Mocha");
            }
        }

        private void americanoFav_button_Click(object sender, EventArgs e)
        {
            if (americanoFav_button.BackColor == Color.White)
            {
                americanoFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Americano");
                flag_5.Visible = true; flag_5.Text = "Added To Favorites";
                timer1.Start();
            }
            else
            {
                americanoFav_button.BackColor = Color.White;
                obj.removeFavorite("Americano");
            }
        }

        ///////////////////// Timer For Labels /////////////
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (flag_1.Visible || flag_2.Visible || flag_3.Visible || flag_4.Visible || flag_5.Visible)
            {
                flag_1.Visible = false;
                flag_2.Visible = false;
                flag_3.Visible = false;
                flag_4.Visible = false;
                flag_5.Visible = false;
                timer1.Stop();
            }

        }
    }


}
