﻿namespace Foodie_menu
{
    partial class favorite2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.flag = new System.Windows.Forms.Label();
            this.cart_button = new System.Windows.Forms.Button();
            this.item_picture = new System.Windows.Forms.PictureBox();
            this.favList = new System.Windows.Forms.ListBox();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.item_picture)).BeginInit();
            this.SuspendLayout();
            // 
            // flag
            // 
            this.flag.AutoSize = true;
            this.flag.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag.ForeColor = System.Drawing.Color.Red;
            this.flag.Location = new System.Drawing.Point(207, 372);
            this.flag.Name = "flag";
            this.flag.Size = new System.Drawing.Size(127, 20);
            this.flag.TabIndex = 4;
            this.flag.Text = "Added To Cart!";
            this.flag.Visible = false;
            // 
            // cart_button
            // 
            this.cart_button.BackColor = System.Drawing.Color.Gold;
            this.cart_button.FlatAppearance.BorderSize = 0;
            this.cart_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cart_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cart_button.ForeColor = System.Drawing.Color.White;
            this.cart_button.Location = new System.Drawing.Point(264, 436);
            this.cart_button.Name = "cart_button";
            this.cart_button.Size = new System.Drawing.Size(144, 27);
            this.cart_button.TabIndex = 2;
            this.cart_button.Text = "Add To Cart";
            this.cart_button.UseVisualStyleBackColor = false;
            this.cart_button.Click += new System.EventHandler(this.cart_button_Click);
            // 
            // item_picture
            // 
            this.item_picture.Location = new System.Drawing.Point(0, 0);
            this.item_picture.Name = "item_picture";
            this.item_picture.Size = new System.Drawing.Size(416, 315);
            this.item_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.item_picture.TabIndex = 1;
            this.item_picture.TabStop = false;
            this.item_picture.Visible = false;
            // 
            // favList
            // 
            this.favList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.favList.BackColor = System.Drawing.Color.Gold;
            this.favList.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.favList.ForeColor = System.Drawing.Color.White;
            this.favList.FormattingEnabled = true;
            this.favList.ItemHeight = 24;
            this.favList.Location = new System.Drawing.Point(414, 0);
            this.favList.Name = "favList";
            this.favList.Size = new System.Drawing.Size(527, 548);
            this.favList.TabIndex = 0;
            this.favList.SelectedIndexChanged += new System.EventHandler(this.favList_SelectedIndexChanged);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 0;
            this.bunifuElipse1.TargetControl = this;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gold;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(102, 436);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(144, 27);
            this.button1.TabIndex = 5;
            this.button1.Text = "Remove";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // favorite2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.item_picture);
            this.Controls.Add(this.flag);
            this.Controls.Add(this.favList);
            this.Controls.Add(this.cart_button);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "favorite2";
            this.Size = new System.Drawing.Size(941, 476);
            this.Load += new System.EventHandler(this.favorite2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.item_picture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label flag;
        private System.Windows.Forms.Button cart_button;
        private System.Windows.Forms.PictureBox item_picture;
        private System.Windows.Forms.ListBox favList;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button1;
    }
}
