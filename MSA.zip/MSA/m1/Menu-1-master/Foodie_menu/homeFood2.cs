﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class homeFood2 : UserControl
    {
        myCart2 obj = new myCart2();
        public homeFood2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        public void work()               ///// Updtaes the user interface on 
        {
            lungoFav_button.BackColor = Color.White;
            blackcoffeeFav_button.BackColor = Color.White;
            espressoFav_button.BackColor = Color.White;
            teaFav_button.BackColor = Color.White;
            mazagranFav_button.BackColor = Color.White;

            foreach (string fav in myCart2.favorites_2)
            {
                if (fav == "Lungo") { lungoFav_button.BackColor = Color.OrangeRed; }
                if (fav == "Black Coffee") { blackcoffeeFav_button.BackColor = Color.OrangeRed; }
                if (fav == "Espresso") { espressoFav_button.BackColor = Color.OrangeRed; }
                if (fav == "Tea") { teaFav_button.BackColor = Color.OrangeRed; }
                if (fav == "Mazagran") { mazagranFav_button.BackColor = Color.OrangeRed; }
            }

            if (obj.GET_Reviews(0) <= 5) { lungo_rating.Value = obj.GET_Reviews(5); }
            else { lungo_rating.Value = 5; }
            if (obj.GET_Reviews(1) <= 5) { blackcoffee_rating.Value = obj.GET_Reviews(6); }
            else { blackcoffee_rating.Value = 5; }
            if (obj.GET_Reviews(2) <= 5) { espresso_rating.Value = obj.GET_Reviews(7); }
            else { espresso_rating.Value = 5; }
            if (obj.GET_Reviews(3) <= 5) { tea_rating.Value = obj.GET_Reviews(8); }
            else { tea_rating.Value = 5; }
            if (obj.GET_Reviews(4) <= 5) { mazagran_rating.Value = obj.GET_Reviews(9); }
            else { mazagran_rating.Value = 5; }
        }

        ////////////////  Add to cart buttons  //////////////
        private void lungo_button_Click(object sender, EventArgs e)
        {
            obj.addItem("Lungo");
            if (myCart2.index1_2 < 20)
                flag_1.Visible = true; flag_1.Text = "Added To Cart";
            timer1.Start();

        }

        private void blackCoffee_button_Click(object sender, EventArgs e)
        {
            obj.addItem("Black Coffee");
            if (myCart2.index1_2 < 20)
                flag_2.Visible = true; flag_2.Text = "Added To Cart";
            timer1.Start();
        }

        private void espresso_button_Click(object sender, EventArgs e)
        {
            obj.addItem("Espresso");
            if (myCart2.index1_2 < 20)
                flag_3.Visible = true; flag_3.Text = "Added To Cart";
            timer1.Start();
        }

        private void tea_button_Click(object sender, EventArgs e)
        {
            obj.addItem("Tea");
            if (myCart2.index1_2 < 20)
                flag_4.Visible = true; flag_4.Text = "Added To Cart";
            timer1.Start();
        }

        private void mazagran_button_Click(object sender, EventArgs e)
        {
            obj.addItem("Mazagran");
            if (myCart2.index1_2 < 20)
                flag_1.Visible = true; flag_1.Text = "Added To Cart";
            timer1.Start();
        }

        ///////////////       Add to favorites       //////////////
        private void lungoFav_button_Click(object sender, EventArgs e)
        {
            if (lungoFav_button.BackColor == Color.White)
            {
                lungoFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Lungo");
                flag_1.Visible = true; flag_1.Text = "Added To Favorites";
                timer1.Start();
            }
            else
            {
                lungoFav_button.BackColor = Color.White;
                obj.removeFavorite("Lungo");
            }
        }

        private void blackcoffeeFav_button_Click(object sender, EventArgs e)
        {
            if (blackcoffeeFav_button.BackColor == Color.White)
            {
                blackcoffeeFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Black Coffee");
                flag_2.Visible = true; flag_2.Text = "Added To Favorites";
                timer1.Start();
            }
            else
            {
                blackcoffeeFav_button.BackColor = Color.White;
                obj.removeFavorite("Black Coffee");
            }
        }

        private void espressoFav_button_Click(object sender, EventArgs e)
        {
            if (espressoFav_button.BackColor == Color.White)
            {
                espressoFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Espresso");
                flag_3.Visible = true; flag_3.Text = "Added To Favorites";
                timer1.Start();
            }
            else
            {
                espressoFav_button.BackColor = Color.White;
                obj.removeFavorite("Espresso");
            }
        }

        private void teaFav_button_Click(object sender, EventArgs e)
        {
            if (teaFav_button.BackColor == Color.White)
            {
                teaFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Tea");
                flag_4.Visible = true; flag_4.Text = "Added To Favorites";
                timer1.Start();
            }
            else
            {
                teaFav_button.BackColor = Color.White;
                obj.removeFavorite("Tea");
            }
        }

        private void mazagranFav_button_Click(object sender, EventArgs e)
        {
            if (mazagranFav_button.BackColor == Color.White)
            {
                mazagranFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Mazagran");
                flag_5.Visible = true; flag_5.Text = "Added To Favorites";
                timer1.Start();
            }
            else
            {
                mazagranFav_button.BackColor = Color.White;
                obj.removeFavorite("Mazagran");
            }
        }




        /////////////////////    Timer For Labels   ////////////////
        ///
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (flag_1.Visible || flag_2.Visible || flag_3.Visible || flag_4.Visible || flag_5.Visible)
            {
                flag_1.Visible = false;
                flag_2.Visible = false;
                flag_3.Visible = false;
                flag_4.Visible = false;
                flag_5.Visible = false;
                timer1.Stop();
            }
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flag_5_Click(object sender, EventArgs e)
        {

        }

        private void flag_4_Click(object sender, EventArgs e)
        {

        }

        private void flag_3_Click(object sender, EventArgs e)
        {

        }
    }


}
